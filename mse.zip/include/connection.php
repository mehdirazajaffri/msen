<?php
$conn = mysqli_connect('localhost', 'root','', 'msen');