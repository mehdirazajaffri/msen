<section id="bottom">
    <div class="center wow fadeInDown">
        <h2>Ongoing Projects</h2>
    </div>
    <?php
include_once"news.php";
?>
</section>