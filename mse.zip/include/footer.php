<footer id="footer" class="midnight-blue">
<div class="container">
<div class="row">
<div class="col-sm-6">
&copy; Muslim Schools Education Network
</div>
<div class="col-sm-6">
<ul class="pull-right">
<li>
    <a href="https://www.facebook.com/pages/msenetwork/637043253099302"><i class="fa fa-facebook-square fa-2x"></i></a>
</li>
<li>
    <a href="https://twitter.com/msenetw0rk"><i class="fa fa-twitter-square fa-2x"></i></a>
</li>
    <li>
        <a href="https://uk.linkedin.com/pub/muslim-schools-education-network/101/575/a72"><i class="fa fa-linkedin-square fa-2x"></i></a>
    </li>
    <li>
        <a href="https://www.youtube.com/channel/UCiDaYbhgmJAbT1svuHubO-g"><i class="fa fa-youtube-square fa-2x"></i></a>
    </li>
    
</ul>
</div>
</div>
</div>
</footer>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/main.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/jquery.bootstrap.newsbox.js"></script>
<script src="js/jquery.bootstrap.newsbox.min.js"></script>
<script src="js/jquery.bootstrap.newsbox.min.js" type="text/javascript"></script>
<script src="js/slick.js"></script>
</body>
</html>