<?php
include"include/header.php";
?>
    <div style="color: white;" class="top-bar center">
    <img class="img-responsive center-block" src="images/bis.png">
    </div>
<?php
include_once"include/wowslider.php";
include_once"include/message.php";
include_once"include/Aims.php";
include_once"include/recent_work.php";
include_once "include/upcoming_events.php";
include_once"include/footer.php";
?>