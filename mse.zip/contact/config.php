<?php
// To
define("WEBMASTER_EMAIL", 'mehdirazajaffri@gmail.com');
?>